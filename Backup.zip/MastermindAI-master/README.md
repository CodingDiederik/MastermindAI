# MastermindAI
MastermindAI project for school, using David Knuth's algorithm
